public class App {//1CEI1217 大西凜 最終課題
    /*今はデータとプログラムが一体になっているが、プログラムを１つにしてデータだけ変えれば情報を追加できるようにする
たとえば、ヒントの文字列を配列に入れておけば、何回目かの変数でその配列の要素を参照するだけでswitch文を使う必要がなくなる*/
    public static void feeling(String[] emotions){
        String emo[]=
        {"愛憎","楽観","病的状態","積極性","誇り","冷笑","悲観","軽蔑",
        "嫉妬","憤慨","自責","不信","恥","失望","絶望","感傷",
        "畏敬","好奇心","歓喜","服従","罪悪感","不安","愛","希望",
        "優位","楽しい","怒り","悲しみ","悲痛","喜び","恐れ","驚き",
        "嫌悪","期待","信頼","恍惚","警戒","激怒","憎悪","驚嘆",
        "恐怖","感嘆","平穏","興味","煩さ","憂い","退屈","動揺",
        "心配","容認","傲慢","憤怒","怠惰","強欲","暴食","色欲",
        "慈悲","忍耐","勤勉","救恤","節制","謙譲","純潔","叡智",
        "悪意","闘争","殺意","絶滅","破滅","滅亡","魔法","キラメンタル",
        "ガッチャ！","忍タリティ","ビルド","ラブ＆ピース","ブレイブ","イマジネーション","モカってる","ツグってる",
        "ノアってる","むにってる","ルミナってる","エモい","可愛い","尊い","記憶","正義",
        "絶対悪","バンド","DJ","システム","技能","技術","神聖術","歌唱",
        "科学","音楽","宇宙","神代"};
        for(int i=0;i<emo.length;i++){
            emotions[i]=emo[i];}
    }
    public static void sub(String[] number){
        String numbers[]={"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
        "20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39", 
        "40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58","59",
        "60","61","62","63","64","65","66","67","68","69","70","71","72","73","74","75","76","77","78","79",
        "80","81","82","83","84","85","86","87","88","89","90","91","92","93","94","95","96","97","98","99"};
        String emotions[]=new String[numbers.length];
        feeling(emotions);
        for(int i=0;i<numbers.length;i++){
            emotions[i]=numbers[i];
            number[i]=emotions[i];
        }
    }
    public static void mission(int[] numbering){
        String number[]=new String[100];
        sub(number);
        int[] num=new int[number.length];
        for(int i=0;i<number.length;i++){
            num[i]=Integer.parseInt(number[i]);
            numbering[i]=num[i];
        }
    }
    public static void lasthint(String[] hint){
        String lasthintlist[]={
            "○○関係","「全ての可能性を信じ、世の中や人生を良いものと考えること」","病気ないし○○○○の本質を研究する学問の1つが病理学","進んで物事を行おうとする性質","ドイツ語でstolzを意味する",
            "他人を○○する","ドイツ語でPessimismusを意味する","ドイツ語でVerachtungを意味する","他人の出世を○○する","ドイツ語でEmpörungを意味する","ドイツ語でSelbstvorwürfeを意味する",
            "ドイツ語でMisstauenを意味する","ドイツ語でSchamを意味する","ドイツ語でEnttäuschungを意味する","ゲートと呼ばれる存在が○○するとファントムを生み出す","ドイツ語でSentimentalitätを意味する",
            "ドイツ語でEhrfurchtを意味する","ある物事に引き付けられる気持ち","ドイツ語でFreudeを意味する","○○のプロセス","○○○に苛まれる","○○感","ドイツ語でLiebeを意味する","ドイツ語でHoffnungを意味する",
            "ドイツ語でÜberlegenheitを意味する","ドイツ語でSpaβを意味する","おこっていること","悲嘆","ドイツ語でHerzschmerzを意味する","慶び","ドイツ語でFurchtを意味する","年齢的な差異は殆ど無い",
            "同族○○","ドイツ語でErwartungenを意味する","○○度","ドイツ語でEkstaseを意味する","ドイツ語でWachsamkeitを意味する","怒りの段階の1つである","ドイツ語でHassを意味する","ドイツ語でStaunenを意味する",
            "○○心","ドイツ語でBewunderungを意味する","ドイツ語でFriedenを意味する","ドイツ語でInteresseを意味する","むしゃくしゃ","ドイツ語でTraurigkeitを意味する","つまらないこと",
            "ドイツ語でverärgernを意味する","ドイツ語でAngstを意味する","ドイツ語でAnnahmeを意味する","ドイツ語でArroganzを意味する","ドイツ語でWutを意味する","○○の魔女","魔女教大罪司教○○担当",
            "○○の悪魔","ドイツ語でLustを意味する","「他者の苦しみを理解し、その苦しみを和らげることを心から願う感情や態度を指します」","じっと耐え忍ぶこと","たゆまずに一所懸命にあることを続けていく様",
            "○○の王","○○の天使","○○語","スズランの花言葉","人類の○○","「他の存在を憎み、害を加えようとする気持ち」","○○を求める","○○の衝動","人類が○○する","○○的思考","睡蓮の花言葉","○○科高校の劣等生",
            "○○○○○○湧いてきた","「○○○○○を追い求め、創作料理を作ったりしている」","喪失すると忍びとしての資格を失うことと同義である","○○○が創る明日","愛と平和","強き竜の者であるキョウリュウジャーに変身するために必要な力",
            "トッキュウジャーに変身するために必要な力","冗談めかした言動が多いがひょうひょうとした態度の裏側には強く大きな情熱を抱えている","頑張っているさま","「カワイイ」という概念への情景がある",
            "よさがわからないやつはミュートする","演算結果に順応なAI","感情的なさま","本気で対象となる事物を○○○○と思っていない場合に用いる","「本来の意味を超越するほど素晴らしく、他に比べるものがないくらい好きである」",
            "地球の本棚に○○されているもの","○○は巡る","必要悪とは異なる","次世代ガールズ○○○プロジェクト","「○○*アニメ*ゲームでおくる、全く新しいメディアミックスプロジェクトD4○○」",
            "対義語として部品や要素を表す「モジュール」「パーツ」がある","「魔物肉を直接食し、肉体を回復することで取得出来、取得者が出来る項目が増加することで派生として現れる」","からめ手を得意とする隊員が特殊○○が高い",
            "全8種存在する","AI○○ソフトが存在している","○○知識","Remixすれば曲の印象が変わる","○○で唯一の”魂のパートナー”「ソウルバディ」","図説○○文字入門"};
        for(int i=0;i<lasthintlist.length;i++){
            hint[i]=lasthintlist[i];
        }
    }
    public static String add(String Emotion){
        int[]numbering=new int[100];
        mission(numbering);
        int[]Addwords=new int[25];
        int m=0;
        while (m<Addwords.length) {
            Addwords[m]=numbering[m];
            switch (numbering[m]) {
                case 0:Emotion="Love And Hate";
                break;
                case 1:Emotion="Optimism "+"(=Anticipation "+"+Joy)";
                break;
                case 2:Emotion="Morbidness "+"(=Disgust "+"+Joy)";
                break;
                case 3:Emotion="Aggressiveness "+"(=Anger "+"+Anticipation)";
                break;
                case 4:Emotion="Pride "+"(=Anger "+"+Joy)";
                break;
                case 5:Emotion="Cynicism "+"(=Disgust "+"+Anticipation)";
                break;
                case 6:Emotion="Pessimism "+"(=Sadness "+"+Anticipation)";
                break;
                case 7:Emotion="Contempt "+"(=Disgust "+"+Anger)";
                break;
                case 8:Emotion="Envy "+"(=Sadness "+"+Anger)";
                break;
                case 9:Emotion="Outrage "+"(=Surprise "+"+Anger)";
                break;
                case 10:Emotion="Remorse "+"(=Sadness "+"+Disgust)";
                break;
                case 11:Emotion="Unbelief "+"(=Surprise "+"+Disgust)";
                break;
                case 12:Emotion="Shame "+"(=Fear "+"+Disgust)";
                break;
                case 13:Emotion="Disappointment "+"(=Surprise "+"+Sadness)";
                break;
                case 14:Emotion="Despair "+"(=Fear "+"+Sadness)";
                break;
                case 15:Emotion="Sentimentality "+"(=Trust "+"+Sadness)";
                break;
                case 16:Emotion="Awe "+"(=Fear "+"+Surprise)";
                break;
                case 17:Emotion="Curiosity "+"(=Trust "+"+Surprise)";
                break;
                case 18:Emotion="Delight "+"(=Joy "+"+Surprise)";
                break;
                case 19:Emotion="Submission "+"(=Trust "+"+Fear)";
                break;
                case 20:Emotion="Guilt "+"(=Joy "+"+Fear)";
                break;
                case 21:Emotion="Anxiety "+"(=Anticipation "+"+Fear)";
                break;
                case 22:Emotion="Love "+"(=Joy "+"+Trust)";
                break;
                case 23:Emotion="Hope "+"(=Anticipation "+"+Trust)";
                break;
                case 24:Emotion="Dominance "+"(=Anger "+"+Trust)";
                break;
                default:Emotion="null";
                break;
            }
            m++;
        }
        return Emotion;
    }
    public static String pull(String Decrease){
        int[]numbering=new int[100];
        mission(numbering);
        int[]Decreasewords=new int[50];
        int n=25;
        while (n<Decreasewords.length) {
            Decreasewords[n]=numbering[n];
            switch (numbering[n]) {
                case 25:Decrease="Enjoy "+"(=joy, anger, sadness, Enjoy "+"-joy "+"-anger "+"-sadness)";
                break;
                case 26:Decrease="Anger "+"(=Happy laughing angry cursing "+"-happy "+"-laugh "+"-curse)";
                break;
                case 27:Decrease="Sad "+"(=grieving parents "+"-A sad one "+"-father "+"-mother)";
                break;
                case 28:Decrease="Grief "+"(=separation pain "+"-Love "+"-break up "+"-Leave)";
                break;
                case 29:Decrease="Joy "+"(=Crazy dance "+"-go crazy "+"-be disturbed "+"-dance)";
                break;
                case 30:Decrease="Fear "+"(=I apologize for the inconvenience "+"-one fear "+"-Greetings)";
                break;
                case 31:Decrease="Surprise "+"(=Shocking heart "+"-heart "+"-move "+"-spirit)";
                break;
                case 32:Decrease="Disgust "+"(=self hate "+"-self)";
                break;
                case 33:Decrease="Anticipation "+"(=Expected value "+"-value)";
                break;
                case 34:Decrease="Trust "+"(=Confidence growth curve "+"-degree "+"-growth curve)";
                break;
                case 35:Decrease="Ecstasy "+"(=ecstatic person "+"-of "+"-person)";
                break;
                case 36:Decrease="Vigilance "+"(=restricted area "+"-area)";
                break;
                case 37:Decrease="Rage "+"(=rage syndrome "+"-syndrome)";
                break;
                case 38:Decrease="Loathing "+"(=thoughts of hatred "+"-of "+"-Thought)";
                break;
                case 39:Decrease="Amazement "+"(=amazing "+"-to "+"-worthy)";
                break;
                case 40:Decrease="Terror "+"(=Be afraid! "+"-do "+"-!)";
                break;
                case 41:Decrease="Admiration "+"(=Exclamation point "+"-sign)";
                break;
                case 42:Decrease="Serenity "+"(=Peaceful and safe "+"-safely)";
                break;
                case 43:Decrease="Interest "+"(=Interesting "+"-all over)";
                break;
                case 44:Decrease="Annoyance "+"(=complicated world "+"-rough "+"-world)";
                break;
                case 45:Decrease="Pensiveness "+"(=gloomy future "+"-Depressed "+"-future)";
                break;
                case 46:Decrease="Boredom "+"(=boredom psychology "+"-psychoygy)";
                break;
                case 47:Decrease="Distraction "+"(=agitated gait "+"-gender "+"-walking)";
                break;
                case 48:Decrease="Apprehension "+"(=Anxiety "+"-case)";
                break;
                case 49:Decrease="Acceptance "+"(acceptable pronunciation "+"-pronunciation)";
                break;
                default:Decrease="null";
                break;
            }
            n++;
        }
        return Decrease;
    }
    public static String Squared(String Deadlysins){
        int[]numbering=new int[100];
        mission(numbering);
        int[]Deadlysinswords=new int[56];
        int o=50;
        while (o<Deadlysinswords.length) {
            Deadlysinswords[o]=numbering[o];
            switch (numbering[o]) {
                case 50:Deadlysins="Arrogance "+"(=be laughed at* "+"Complex)";
                break;
                case 51:Deadlysins="Wrath "+"(=Reason disappears* "+"Instinctive massacre)";
                break;
                case 52: Deadlysins="Lazy "+"(=The neighborhood large consumption* "+"Self efficiency)";
                break;
                case 53:Deadlysins="Greed "+"(=I plunder the killing partner of it partly at random* "+"The greed that is not satisfied)";
                break;
                case 54:Deadlysins="Gluttony "+"(=I can eat it targeting at every thing* "+"Eternity hunger)";
                break;
                case 55:Deadlysins="Lust "+"(=I give state abnormality of the \"hypnosis\" \"charm\" \"brainwashing\" to a partner* "+"Intense loathsomeness)";
                break;
                default:Deadlysins="null";
                break;
            }
            o++;
        }
        return Deadlysins;
    }
    public static String Multiplicationdivision(String Virtues){
        int[]numbering=new int[100];
        mission(numbering);
        int[]Virtueswords=new int[64];
        int p=56;
        while (p<Virtueswords.length) {
            Virtueswords[p]=numbering[p];
            switch (numbering[p]) {
                case 56:Virtues="Mercy "+"(=resurrection of the dead* "+"Taboo"+"/self)";
                break;
                case 57:Virtues="Patience "+"(=death avoidance* " +"Defense/resistance ability increase and resistance proficiency correction* "+"Resistance proficiency correction "+"/Patience)";
                break;
                case 58:Virtues="Diligence "+"(=Erosion takeover to move the soul* "+"half immortal "+"/the will of others)";
                break;
                case 59:Virtues="Relief "+"(=Super fast recovery of physical strength to self and allies* "+"donation "+"/stock)";
                break;
                case 60:Virtues="Temperance "+"(=Reincarnation with memory of previous life retained* "+"Practically immortal "+"/fraud)";
                break;
                case 61:Virtues="Humility "+"(=Consume your soul to gain power equal to that of a god* "+"equal position "+"/Discomfort)";
                break;
                case 62:Virtues="Purity "+"(=Expand your own divine realm* "+"develop a powerful barrier "+"/sexual relationship)";
                break;
                case 63:Virtues="Wisdom "+"(=View all information* "+"mapping* "+"tracking* "+"The height of magic* "+"Star demon "+"/rejection)";
                break;
                default:Virtues="null";
                break;
            }
            p++;
        }
        return Virtues;
    }
    public static String arithmeticoperation(String Perfectconclusion){
        int[]numbering=new int[100];
        mission(numbering);
        int[]Perfectconclusionwords=new int[70];
        int q=64;
        while (q<Perfectconclusionwords.length) {
            Perfectconclusionwords[q]=numbering[q];
            switch (numbering[q]) {
                case 64:Perfectconclusion="Malice "+"(=deep sorrow* "+"hatred "+"%It is every feeling except one)";
                break;
                case 65:Perfectconclusion="Struggle "+"(=The ceremony that it spoils* "+"Hidden fighting instinct "
                +"%It doesn't matter if it's exactly the same)";
                break;
                case 66:Perfectconclusion="Intention to kill "+"(=As for the love and the desire among oneself* "+"Existence not to be able to notice declares it "
                +"→I can look for it in a heart)";
                break;
                case 67:Perfectconclusion="Extinction "+"Decrease in individuals* "+"cease to exist from the stars "+"→balance is damaged";
                break;
                case 68:Perfectconclusion="Catastrophe "+"(=flag to die* "+"growing fast and slow "+"→beyond creation";
                break;
                case 69:Perfectconclusion="destruction "+"(=suffer catastrophic damage* "+"The fate I lost "+"→want to avoid";
                break;
                default:Perfectconclusion="null";
                break;
            }
            q++;
        }
        return Perfectconclusion;
    }
    public static String conversion(String Changefullthrottle){
        int numbering[]=new int[100];
        mission(numbering);
        int[]Changefullthrottlewords=new int[numbering.length];
        int r=70;
        while(r<Changefullthrottlewords.length){
            Changefullthrottlewords[r]=numbering[r];
            switch (numbering[r]) {
                case 70:Changefullthrottle="Magic "+"(=It's holy power, it's an adventure into the unknown, and it's a proof of courage.)";
                break;
                case 71:Changefullthrottle="Chiramental "+"(=shining spirit)";
                break;
                case 72:Changefullthrottle="Gotcha "+"(=something just for me)";
                break;
                case 73:Changefullthrottle="Shinobi Tality "+"(=Mental strength, such as the way each person's heart and spirit is held toward ninjas)";
                break;
                case 74:Changefullthrottle="Build "+"(=Create, form)";
                break;
                case 75:Changefullthrottle="Love and peace " +"(=love & peace)";
                break;
                case 76:Changefullthrottle="Brave "+"(=``Not only 'brave', but also the power of the heart that was not present on the destroyed asteroid, and is said to be the human spirit that burns together and overcomes despair.'')";
                break;
                case 77:Changefullthrottle="Imagination "+"(=imagination)";
                break;
                case 78:Changefullthrottle="It's mocha "+"(=go at your own pace)";
                break;
                case 79:Changefullthrottle="I'm confused "+"(=doing my best)";
                break;
                case 80:Changefullthrottle="Noah is here "+"(=It's like you don't have an eye for cute things)";
                break;
                case 81:Changefullthrottle="be disgusted with "+"(=So that I behave like a baby to a partner detecting oneself, but guard is firm for the partner who is not so)";
                break;
                case 82:Changefullthrottle="luminous "+"(=The way an AI (machine people) with emotions behaves like an AI (machine people) without emotions.)";
                break;
                case 83:Changefullthrottle="Emotional "+"(=What an indescribably wonderful feeling!)";
                break;
                case 84:Changefullthrottle="Cute "+"(=Feeling attracted to small and weak things)";
                break;
                case 85:Changefullthrottle="precious "+"(=wonderful, the best)";
                break;
                case 86:Changefullthrottle="Memory "+"(=Something created by the overlap of time, a specific event)";
                break;
                case 87:Changefullthrottle="justice "+"(=embodiment of the ideal,hypocrisy,correct reason, a righteous principle that exists as many as there are)";
                break;
                case 88:Changefullthrottle="absolute evil "+"(=Names, society, and civilization will all be reduced to nothing.)";
                break;
                case 89:Changefullthrottle="Band "+"(=Common destiny)";
                break;
                case 90:Changefullthrottle="DJ "+"(=``The person who selects and plays records at dance clubs and discos'', the person who connects existence and music.)";
                break;
                case 91:Changefullthrottle="System "+"(=An organization or system in which many elements come together in a cohesive manner.)";
                break;
                case 92:Changefullthrottle="Skill "+"(=Ability related to changing jobs as a very rare “talent”)";
                break;
                case 93:Changefullthrottle="Technology "+"(=Accuracy and precision of attack and defense)";
                break;
                case 94:Changefullthrottle="Sacred art "+"(=It has 8 different strains and consumes divine power.)";
                break;
                case 95:Changefullthrottle="Singing "+"(=singing a song)";
                break;
                case 96:Changefullthrottle="Science "+"(=Steady efforts to find rules for things we don't understand)";
                break;
                case 97:Changefullthrottle="Music "+"(=Art by sound, instrumental music and vocal music, something that releases the power hidden in humans.)";
                break;
                case 98:Changefullthrottle="Universe "+"(=The entire space and time, a space that extends forward, backward, left, right, up and down, and time that extends from the past to the future.``Every time the song changes due to synesthesia, the sound of the entire venue and the color of people's feelings change.'')";
                break;
                case 99:Changefullthrottle="Age of gods "+"(=An era in which there were gods in the lower world, showing the name of the magic known as Logic that twisted the principles of the stars.)";
                break;
                default:Changefullthrottle="null";
                break;
            }
            r++;
        }
        return Changefullthrottle;
    }
    public static String scanaria(String scan) {
        java.util.Scanner scanner=new java.util.Scanner(System.in);
        String l=scanner.nextLine();
        return l;
    }
    public static void main(String[] args) throws Exception {
        String emotions[]=new String[100];
        feeling(emotions);
        for(int i=0;i<emotions.length;i++){
            String x=emotions[i];
            System.out.println("感情を含む用語一覧: "+x);}
            String add="1";
            adderia(add);
            String pull="2";
            pullaria(pull);
            String Squared="3";
            Squaredaria(Squared);
            String Multiplicationdivision="4";
            Multiplicationdivisionaria(Multiplicationdivision);
            String arithmeticoperation="5";
            arithmeticoperationaria(arithmeticoperation);
            String conversion="6";
            conversionaria(conversion);
            System.out.println("ゲームを終了します");
        }
    public static void adderia(String add){
        System.out.println("加算エリア");
        int c=0;
        String l="0";
        String hint[]=new String[100];
        lasthint(hint);
        while(c<2){
            int y=new java.util.Random().nextInt(25);
            c++;
            switch (y) {
                case 0:{
                    System.out.println("愛と憎しみを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("愛憎")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情、基本感情、強い感情、弱い感情のどれにも位置しない」");
                                break;
                                case 1:System.out.println("ヒント:反対の語句が並んでいる");
                                break;
                                case 2:System.out.println("ヒント:○○の念が入り混じる");
                                break;
                                case 3:System.out.println("ヒント:○○相半ばする");
                                break;
                                case 4:System.out.println("ヒント:特に相手に対して好悪の感情を抱くこと");
                                break;
                                case 5:System.out.println("ヒント:一組の存在達の間に生じる全く対照的な感情");
                                break;
                                case 6:System.out.println("ヒント:○○関係");
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("○○関係")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    } 
                }
                break;
                case 1:{
                    System.out.println("期待と喜びを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("楽観")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:世界を軽く考えている");
                                break;
                                case 2:System.out.println("ヒント:物事の先行きを良い方に考えて心配しない事");
                                break;
                                case 3:System.out.println("ヒント:心配するほどのことではないとして気楽に考えること");
                                break;
                                case 4:System.out.println("ヒント:病状は○○を許さない");
                                break;
                                case 5:System.out.println("ヒント:状況を○○する");
                                break;
                                case 6:System.out.println("ヒント:「全ての可能性を信じ、世の中や人生を良いものと考えること」");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("「全ての可能性を信じ、世の中や人生を良いものと考えること」")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    } 
                }
                break;
                case 2:{
                    System.out.println("嫌悪と喜びを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("病的状態")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:矛盾している状態");
                                break;
                                case 2:System.out.println("ヒント:「無能感が個人を圧倒し、有益な活動へ刺激するどころか、人を落ち込ませ、成長出来ないときの劣等感」");
                                break;
                                case 3:System.out.println("ヒント:認知症が含まれる");
                                break;
                                case 4:System.out.println("ヒント:病識とは患者自身が○○○○にあると自覚する事");
                                break;
                                case 5:System.out.println("ヒント:過剰なストレス刺激は精神的な○○○○の原因となる");
                                break;
                                case 6:System.out.println("ヒント:病気ないし○○○○の本質を研究する学問の1つが病理学");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("病気ないし○○○○の本質を研究する学問の1つが病理学")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 3:{
                    System.out.println("怒りと期待を合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("積極性")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:自発的に動くこと");
                                break;
                                case 2:System.out.println("ヒント:物事に対して能動的に行動する姿勢");
                                break;
                                case 3:System.out.println("ヒント:○○○を養う");
                                break;
                                case 4:System.out.println("ヒント:○○○のある人");
                                break;
                                case 5:System.out.println("ヒント:賢明な○○○");
                                break;
                                case 6:System.out.println("ヒント:進んで物事を行おうとする性質");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("進んで物事を行おうとする性質")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 4:{
                    System.out.println("怒りと喜びを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("誇り")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:自信を持っている");
                                break;
                                case 2:System.out.println("ヒント:みずからそれを名誉とする感情");
                                break;
                                case 3:System.out.println("ヒント:一家の○○");
                                break;
                                case 4:System.out.println("ヒント:○○を傷つけられる");
                                break;
                                case 5:System.out.println("ヒント:○○を尊重する");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でstolzを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でstolzを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 5:{
                    System.out.println("嫌悪と期待を合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("冷笑")){
                            System.out.println("正解:"+add(Emotion));
                        break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:さげすみ見下した態度で見ること");
                                break;
                                case 2:System.out.println("ヒント:「さげすみ、みくだした態度で笑う事」");
                                break;
                                case 3:System.out.println("ヒント:あざわらうこと");
                                break;
                                case 4:System.out.println("ヒント:○○主義");
                                break;
                                case 5:System.out.println("ヒント:○○を浮かべる");
                                break;
                                case 6:System.out.println("ヒント:他人を○○する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("他人を○○する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 6:{
                    System.out.println("悲しみと期待を合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("悲観")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:事態を暗い向きに見ること");
                                break;
                                case 2:System.out.println("ヒント:好ましい状態にならないだろうと前途を悲しんで考えること");
                                break;
                                case 3:System.out.println("ヒント:「人生・世界・宇宙は苦しみや悪ばかりだとする、物の見方」");
                                break;
                                case 4:System.out.println("ヒント:先行きに望みは無いと考えるさま");
                                break;
                                case 5:System.out.println("ヒント:望みの持てないさま");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でPessimismusを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でPessimismusを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 7:{
                    System.out.println("嫌悪と怒りを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("軽蔑")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:馬鹿にすること");
                                break;
                                case 2:System.out.println("ヒント:かろんじさげすむこと");
                                break;
                                case 3:System.out.println("ヒント:「いやしい、劣っている、つまらないなどと感じて馬鹿にすること」");
                                break;
                                case 4:System.out.println("ヒント:かるくみてあなどること");
                                break;
                                case 5:System.out.println("ヒント:見下げること");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でVerachtungを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でVerachtungを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 8:{
                    System.out.println("悲しみと怒りを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("嫉妬")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情及び七大罪に位置している」");
                                break;
                                case 1:System.out.println("ヒント:相手のスキルを強制的に使用不能（封印）することが出来るが、感情の抑制が効きにくくなってしまう");
                                break;
                                case 2:System.out.println("ヒント:相手を愛する反動");
                                break;
                                case 3:System.out.println("ヒント:「独占欲を満たせないときに瞬時に生まれる、消しがたい感情」");
                                break;
                                case 4:System.out.println("ヒント:SNSでの「いいね!」の裏の感情");
                                break;
                                case 5:System.out.println("ヒント:自分より優れた者を羨んだり、妬んだりすること");
                                break;
                                case 6:System.out.println("ヒント:他人の出世を○○する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("他人の出世を○○する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 9:{
                    System.out.println("驚きと怒りを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("憤慨")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:酷く腹を立てること");
                                break;
                                case 2:System.out.println("ヒント:けしからぬ事に対していきどおりなげくこと");
                                break;
                                case 3:System.out.println("ヒント:身勝手な振る舞いに○○する");
                                break;
                                case 4:System.out.println("ヒント:涼宮ハルヒの○○");
                                break;
                                case 5:System.out.println("ヒント:非常に腹を立てている様子");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でEmpörungを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でEmpörungを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 10:{
                    System.out.println("悲しみと嫌悪を合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("自責")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:自分で自分の過ちを責めること");
                                break;
                                case 2:System.out.println("ヒント:○○思考");
                                break;
                                case 3:System.out.println("ヒント:○○の念に駆られる");
                                break;
                                case 4:System.out.println("ヒント:○○点");
                                break;
                                case 5:System.out.println("ヒント:過度な○○思考は鬱の原因");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でSelbstvorwürfeを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でSelbstvorwürfeを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 11:{
                    System.out.println("驚きと嫌悪を合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("不信")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:信用しない事");
                                break;
                                case 2:System.out.println("ヒント:信義がない事");
                                break;
                                case 3:System.out.println("ヒント:不実");
                                break;
                                case 4:System.out.println("ヒント:○○の念を抱く");
                                break;
                                case 5:System.out.println("ヒント:信仰心のない事");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でMisstauenを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でMisstauenを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 12:{
                    System.out.println("恐れと嫌悪を合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("恥")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:きまり悪く思う");
                                break;
                                case 2:System.out.println("ヒント:はずかしく思う");
                                break;
                                case 3:System.out.println("ヒント:世の人に対し面目・名誉を失う事");
                                break;
                                case 4:System.out.println("ヒント:はずべき事柄をはずかしいと思う存在らしい心");
                                break;
                                case 5:System.out.println("ヒント:○○を忍んでお願いする");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でSchamを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でSchamを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                    break;
                }
                case 13:{
                    System.out.println("驚きと悲しみを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("失望")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:とある都市の最高戦力の成長が想定よりも低かった");
                                break;
                                case 2:System.out.println("ヒント:のぞみをうしなうこと");
                                break;
                                case 3:System.out.println("ヒント:あてがはずれてがっかりすること");
                                break;
                                case 4:System.out.println("ヒント:期待や希望が外れた時の気持ちが沈むさま");
                                break;
                                case 5:System.out.println("ヒント:○○落胆");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でEnttäuschungを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でEnttäuschungを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 14:{
                    System.out.println("恐れと悲しみを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("絶望")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情及び負の感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:抗う英雄が産まれる土壌を作るための世界の状況");
                                break;
                                case 2:System.out.println("ヒント:「ある不在の全を獲得し、或いは現存する悪を排除する可能性がまったくなくなった場合の精神状態」");
                                break;
                                case 3:System.out.println("ヒント:希望のない様子");
                                break;
                                case 4:System.out.println("ヒント:ピンチはチャンス");
                                break;
                                case 5:System.out.println("ヒント:望みが絶たれた状態");
                                break;
                                case 6:System.out.println("ヒント:ゲートと呼ばれる存在が○○するとファントムを生み出す");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ゲートと呼ばれる存在が○○するとファントムを生み出す")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 15:{
                    System.out.println("信頼と悲しみを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("感傷")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:ものに感じて心を痛めること");
                                break;
                                case 2:System.out.println("ヒント:「そう思うと、なんだか○○の情に堪えない」");
                                break;
                                case 3:System.out.println("ヒント:「物事に感じやすく、すぐ悲しんだり同情したりする心の傾向」");
                                break;
                                case 4:System.out.println("ヒント:○○に浸る");
                                break;
                                case 5:System.out.println("ヒント:○○的");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でSentimentalitätを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でSentimentalitätを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 16:{
                    System.out.println("恐れと驚きを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("畏敬")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:心から服しうやまうこと");
                                break;
                                case 2:System.out.println("ヒント:崇高なものや偉大な人をおそれうやまうこと");
                                break;
                                case 3:System.out.println("ヒント:○○の念を抱く");
                                break;
                                case 4:System.out.println("ヒント:○○する");
                                break;
                                case 5:System.out.println("ヒント:○○の念に打たれる");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でEhrfurchtを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でEhrfurchtを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 17:{
                    System.out.println("信頼と驚きを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("好奇心")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:珍しいものや自分の知らないものに興味を持つ心");
                                break;
                                case 2:System.out.println("ヒント:奇なるものを好む心");
                                break;
                                case 3:System.out.println("ヒント:○○○旺盛");
                                break;
                                case 4:System.out.println("ヒント:生得的なもの");
                                break;
                                case 5:System.out.println("ヒント:物事を探究しようとする根源的な心");
                                break;
                                case 6:System.out.println("ヒント:ある物事に引き付けられる気持ち");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ある物事に引き付けられる気持ち")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 18:{
                    System.out.println("喜びと驚きを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("歓喜")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:非常に喜ぶこと");
                                break;
                                case 2:System.out.println("ヒント:よろこび");
                                break;
                                case 3:System.out.println("ヒント:○○の声");
                                break;
                                case 4:System.out.println("ヒント:心からの喜び");
                                break;
                                case 5:System.out.println("ヒント:心が滾る");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でFreudeを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でFreudeを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 19:{
                    System.out.println("信頼と恐れを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("服従")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:大人しくして他人の命令や意志に従う事");
                                break;
                                case 2:System.out.println("ヒント:絶対○○");
                                break;
                                case 3:System.out.println("ヒント:○○の心理");
                                break;
                                case 4:System.out.println("ヒント:○○する");
                                break;
                                case 5:System.out.println("ヒント:他に従う事");
                                break;
                                case 6:System.out.println("ヒント:○○のプロセス");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("○○のプロセス")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 20:{
                    System.out.println("喜びと恐れを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("罪悪感")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:社会的、道徳的に非難されるべきことを犯したという意識ないしは感情");
                                break;
                                case 2:System.out.println("ヒント:自身がした行為をざいあくと感じる気持ち");
                                break;
                                case 3:System.out.println("ヒント:○○○を抱く");
                                break;
                                case 4:System.out.println("ヒント:○○○を消す");
                                break;
                                case 5:System.out.println("ヒント:不道徳な行いに伴う恥の気持ち");
                                break;
                                case 6:System.out.println("ヒント:○○○に苛まれる");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("○○○に苛まれる")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 21:{
                    System.out.println("期待と恐れを合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("不安")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:誰もが不通に経験する神経質、心配、困惑の感情");
                                break;
                                case 2:System.out.println("ヒント:幅広い精神障害などでもみられます");
                                break;
                                case 3:System.out.println("ヒント:○○障害");
                                break;
                                case 4:System.out.println("ヒント:○○症");
                                break;
                                case 5:System.out.println("ヒント:○○神経症");
                                break;
                                case 6:System.out.println("ヒント:○○感");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("○○感")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
                case 22:{
                    System.out.println("喜びと信頼を合わせたものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Emotion=scanaria(l);
                        if(Emotion.equals("愛")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:悪い魔法使いが得られなかったもの");
                                break;
                                case 2:System.out.println("ヒント:「そのものの価値を認め、強く引き付けられる気持ち」");
                                break;
                                case 3:System.out.println("ヒント:大事なものとして慕う心");
                                break;
                                case 4:System.out.println("ヒント:かわいがる");
                                break;
                                case 5:System.out.println("ヒント:男女が思いあう");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でLiebeを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でLiebeを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
            break;
            case 23:{
                System.out.println("期待と信頼を合わせたものを何という？");
                System.out.println("回答を入力して下さい");
                for(int i=0;i<7;i++){
                    String Emotion=scanaria(l);
                    if(Emotion.equals("希望")){
                        System.out.println("正解:"+add(Emotion));
                        break;
                    } else{
                        switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:○○の魔法使い");
                                break;
                                case 2:System.out.println("ヒント:未来に望みをかけること");
                                break;
                                case 3:System.out.println("ヒント:「こうなればよい、なってほしいと願う事」");
                                break;
                                case 4:System.out.println("ヒント:その事柄の内容");
                                break;
                                case 5:System.out.println("ヒント:望み通りになるだろうという良い見通し");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でHoffnungを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でHoffnungを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
            break;
            case 24:{
                System.out.println("怒りと信頼を合わせたものを何という？");
                System.out.println("回答を入力して下さい");
                for(int i=0;i<7;i++){
                    String Emotion=scanaria(l);
                    if(Emotion.equals("優位")){
                        System.out.println("正解:"+add(Emotion));
                        break;
                    } else{
                        switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、応用感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:他より立ちまさった(有利な)位置や立場");
                                break;
                                case 2:System.out.println("ヒント:○○に立つ");
                                break;
                                case 3:System.out.println("ヒント:味方に○○な戦局");
                                break;
                                case 4:System.out.println("ヒント:○○性");
                                break;
                                case 5:System.out.println("ヒント:幸福○○");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でÜberlegenheitを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("ドイツ語でÜberlegenheitを意味する")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
            break;
            default:{
                System.out.println("問題");
                System.out.println("回答を入力して下さい");
                for(int i=0;i<7;i++){
                    String Emotion=scanaria(l);
                    if(Emotion.equals("用語")){
                        System.out.println("正解:"+add(Emotion));
                        break;
                    } else{
                        switch (i) {
                                case 0:System.out.println("不正解! ヒント:「所属に所属しており、位置に位置している」");
                                break;
                                case 1:System.out.println("ヒント:");
                                break;
                                case 2:System.out.println("ヒント:");
                                break;
                                case 3:System.out.println("ヒント:");
                                break;
                                case 4:System.out.println("ヒント:");
                                break;
                                case 5:System.out.println("ヒント:");
                                break;
                                case 6:System.out.println("ヒント:");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Emotion="0";
                        if(m.equals("")){
                            System.out.println("正解:"+add(Emotion));
                            break;
                        }
                    }
                }
                break;
            }
        }
    }
    public static void pullaria(String pull) {
        System.out.println("減算エリア");
        int d=0;
        String l="7";
        String hint[]=new String[100];
        lasthint(hint);
        while(d<2){
            d++;
            int z=new java.util.Random().nextInt(25);
            switch (z) {
                case 0:{
                    System.out.println("喜怒哀楽から哀しいと哀しいと怒りを外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int j=0;j<7;j++){
                        String decrease=scanaria(l);
                        if(decrease.equals("楽しい")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (j) {
                                case 0:System.out.println("ヒント:気持ちよく明るい気分だ");
                                break;
                                case 1:System.out.println("不正解! ヒント:「感情に所属しており、基本感情、弱い感情、強い感情、応用感情のどれにも位置しない」");
                                break;
                                case 2:System.out.println("ヒント:戦騎");
                                break;
                                case 3:System.out.println("ヒント:のびのびと満ち足りた気持ちだ");
                                break;
                                case 4:System.out.println("ヒント:愉しい");
                                break;
                                case 5:System.out.println("ヒント:○○○ピクニック");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でSpaβを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でSpaβを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 1:{
                    System.out.println("嬉笑怒罵から嬉しいと笑うと罵るを外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("怒り")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、基本感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:はらだち");
                                break;
                                case 2:System.out.println("ヒント:戦騎");
                                break;
                                case 3:System.out.println("ヒント:いきどおり");
                                break;
                                case 4:System.out.println("ヒント:原初的な感情の一つ");
                                break;
                                case 5:System.out.println("ヒント:○○の状態");
                                break;
                                case 6:System.out.println("ヒント:おこっていること");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("おこっていること")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 2:{
                    System.out.println("哀哀父母から哀しい一つと父と母を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("悲しみ")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:感情に所属しており、強い感情に位置している");
                                break;
                                case 1: System.out.println("ヒント:負の感情の1つ胸が締め付けられるといった身体的感覚");
                                break;
                                case 2:System.out.println("ヒント:戦騎");
                                break;
                                case 3:System.out.println("ヒント:胸が締め付けられるといった身体的感覚");
                                break;
                                case 4:System.out.println("ヒント:○○○に暮れる");
                                break;
                                case 5:System.out.println("ヒント:哀しい気持ちや心");
                                break;
                                case 6:System.out.println("ヒント:悲嘆");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("悲嘆")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 3:{
                    System.out.println("愛別離苦から別れる離れると愛するを外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("悲痛")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、強い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:（見聞きして）心が痛み極めて悲しい事");
                                break;
                                case 2:System.out.println("ヒント:あまりに悲しくて心が痛むこと");
                                break;
                                case 3:System.out.println("ヒント:○○な面持ち");
                                break;
                                case 4:System.out.println("ヒント:○○な叫び");
                                break;
                                case 5:System.out.println("ヒント:悲しさを痛ましく思う事");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でHerzschmerzを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でHerzschmerzを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 4:{
                    System.out.println("狂喜乱舞から狂うと乱れると舞うを外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("喜び")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、基本感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:うれしく思う心・気持ち");
                                break;
                                case 2:System.out.println("ヒント:満足な思い");
                                break;
                                case 3:System.out.println("ヒント:戦騎");
                                break;
                                case 4:System.out.println("ヒント:悦び");
                                break;
                                case 5:System.out.println("ヒント:ドイツ語でFreudeを意味する");
                                break;
                                case 6:System.out.println("ヒント:慶び");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("慶び")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 5:{
                    System.out.println("恐恐謹言から恐れ一つと謹言を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("恐れ")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、基本感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:おそれること");
                                break;
                                case 2:System.out.println("ヒント:悪いことが起こるのではないかという心配");
                                break;
                                case 3:System.out.println("ヒント:懸念");
                                break;
                                case 4:System.out.println("ヒント:畏れ");
                                break;
                                case 5:System.out.println("ヒント:恐怖");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でFurchtを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でFurchtを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 6:{
                    System.out.println("驚心動魄から心と動くと魄を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("驚き")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、基本感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:動物が予期しない事象を体験した時に起こる瞬間的な感情をいう");
                                break;
                                case 2:System.out.println("ヒント:驚愕");
                                break;
                                case 3:System.out.println("ヒント:他の感情に比べて単純かつ原始的");
                                break;
                                case 4:System.out.println("ヒント:生理的反応と強く結びついた情動");
                                break;
                                case 5:System.out.println("ヒント:愕き");
                                break;
                                case 6:System.out.println("ヒント:年齢的な差異は殆ど無い");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("年齢的な差異は殆ど無い")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 7:{
                    System.out.println("自己嫌悪から自己を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("嫌悪")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、基本感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:憎み嫌う事");
                                break;
                                case 2:System.out.println("ヒント:不愉快に思う事");
                                break;
                                case 3:System.out.println("ヒント:不正を○○する");
                                break;
                                case 4:System.out.println("ヒント:○○感");
                                break;
                                case 5:System.out.println("ヒント:ドイツ語でder Ekelを意味する");
                                break;
                                case 6:System.out.println("ヒント:同族○○");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("同族○○")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 8:{
                    System.out.println("期待値から値を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("期待")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、基本感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:ある人がそれをするのを（他の人が）あてにし、心待ちに待つこと");
                                break;
                                case 2:System.out.println("ヒント:将来それが実現するように待ち構えること");
                                break;
                                case 3:System.out.println("ヒント:あることが実現するだろうと望みをかけて待ち受けること");
                                break;
                                case 4:System.out.println("ヒント:「何らかのことが実現するだろう、と望みつつ待つこと」");
                                break;
                                case 5:System.out.println("ヒント:好ましい状態の実現を心の中で待ち望んでいる様子");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でErwartungenを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でErwartungenを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 9:{
                    System.out.println("信頼度成長曲線から度と成長曲線を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("信頼")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、基本感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:頼りに出来るとして信ずること");
                                break;
                                case 2:System.out.println("ヒント:信じて頼りとすること");
                                break;
                                case 3:System.out.println("ヒント:信用して任せること");
                                break;
                                case 4:System.out.println("ヒント:信じて頼りにする気持ち");
                                break;
                                case 5:System.out.println("ヒント:○○性");
                                break;
                                case 6:System.out.println("ヒント:○○度");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("○○度")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 10:{
                    System.out.println("恍惚の人からのと人を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("恍惚")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、強い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「物事に心をうばわれて、うっとりする様」");
                                break;
                                case 2:System.out.println("ヒント:ぼけていること");
                                break;
                                case 3:System.out.println("ヒント:○○として聴き入る");
                                break;
                                case 4:System.out.println("ヒント:○○の境地");
                                break;
                                case 5:System.out.println("ヒント:意識がはっきりしないさま");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でEkstaseを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でEkstaseを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 11:{
                    System.out.println("警戒区域から区域を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("警戒")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、強い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「好ましくないことが起こらないように、注意し用心する事」");
                                break;
                                case 2:System.out.println("ヒント:徹夜で○○にあたる");
                                break;
                                case 3:System.out.println("ヒント:○○レベル");
                                break;
                                case 4:System.out.println("ヒント:インフレを○○する");
                                break;
                                case 5:System.out.println("ヒント:「危険や災害に備えて、あらかじめ注意し、用心すること」");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でWachsamkeitを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でWachsamkeitを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 12:{
                    System.out.println("激怒症候群から症候群を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("激怒")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、強い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:激しく怒る事");
                                break;
                                case 2:System.out.println("ヒント:酷い立腹");
                                break;
                                case 3:System.out.println("ヒント:大○○");
                                break;
                                case 4:System.out.println("ヒント:○○する");
                                break;
                                case 5:System.out.println("ヒント:先生の○○を買う");
                                break;
                                case 6:System.out.println("ヒント:怒りの段階の1つである");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("怒りの段階の1つである")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 13:{
                    System.out.println("憎悪の念からのと念を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("憎悪")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、強い感情及び負の感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:憎み嫌う事");
                                break;
                                case 2:System.out.println("ヒント:酷く憎むこと");
                                break;
                                case 3:System.out.println("ヒント:戦争を○○する");
                                break;
                                case 4:System.out.println("ヒント:○○の科学");
                                break;
                                case 5:System.out.println("ヒント:○○のピラミッド");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でHassを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でHassを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 14:{
                    System.out.println("驚嘆に値するからにと値するを外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("驚嘆")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、強い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:非常に驚くこと");
                                break;
                                case 2:System.out.println("ヒント:大きな驚き");
                                break;
                                case 3:System.out.println("ヒント:びっくりして感心する事");
                                break;
                                case 4:System.out.println("ヒント:酷く感心すること");
                                break;
                                case 5:System.out.println("ヒント:思いがけない出来事に会って驚くこと");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でStaunenを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でStaunenを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 15:{
                    System.out.println("恐怖しろ！からしろと！を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("恐怖")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、強い感情及び負の感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:恐れること");
                                break;
                                case 2:System.out.println("ヒント:恐れる心");
                                break;
                                case 3:System.out.println("ヒント:恐ろしい感じ");
                                break;
                                case 4:System.out.println("ヒント:○○にかられる");
                                break;
                                case 5:System.out.println("ヒント:ドイツ語でFurchtを意味する");
                                break;
                                case 6:System.out.println("ヒント:○○心");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("○○心")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 16:{
                    System.out.println("感嘆符から符を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("感嘆")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、強い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「感心して、ほめること」");
                                break;
                                case 2:System.out.println("ヒント:なげきかなしむこと");
                                break;
                                case 3:System.out.println("ヒント:熱意と努力に○○する");
                                break;
                                case 4:System.out.println("ヒント:○○Ⅱ");
                                break;
                                case 5:System.out.println("ヒント:○○の声を上げる");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でBewunderungを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でBewunderungを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 17:{
                    System.out.println("平穏無事から無事を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("平穏")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、弱い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「変ったことも怒らず、おだやかなさま」");
                                break;
                                case 2:System.out.println("ヒント:○○な日常を送る");
                                break;
                                case 3:System.out.println("ヒント:心の○○");
                                break;
                                case 4:System.out.println("ヒント:静かに穏やかな事");
                                break;
                                case 5:System.out.println("ヒント:○○死");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でFriedenを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でFriedenを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 18:{
                    System.out.println("興味津津から津津を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("興味")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、弱い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:人の関心をそそる面白み");
                                break;
                                case 2:System.out.println("ヒント:ある対象に対する特別の関心");
                                break;
                                case 3:System.out.println("ヒント:○○に満ちた表情");
                                break;
                                case 4:System.out.println("ヒント:○○を引く");
                                break;
                                case 5:System.out.println("ヒント:○○がわく");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でInteresseを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でInteresseを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 19:{
                    System.out.println("煩雑世界から雑と世界を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("煩さ")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、弱い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:わずらわしいこと");
                                break;
                                case 2:System.out.println("ヒント:うるさいこと");
                                break;
                                case 3:System.out.println("ヒント:うるさいさま");
                                break;
                                case 4:System.out.println("ヒント:煩瑣");
                                break;
                                case 5:System.out.println("ヒント:騒音のうるささ");
                                break;
                                case 6:System.out.println("ヒント:むしゃくしゃ");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("むしゃくしゃ")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 20:{
                    System.out.println("憂鬱な未来から鬱なと未来を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("憂い")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、弱い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:思うようにならなくてつらい");
                                break;
                                case 2:System.out.println("ヒント:せつない");
                                break;
                                case 3:System.out.println("ヒント:憂鬱だ");
                                break;
                                case 4:System.out.println("ヒント:愁い");
                                break;
                                case 5:System.out.println("ヒント:悲しみ");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でTraurigkeitを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でTraurigkeitを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 21:{
                    System.out.println("退屈心理から心理を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("退屈")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、弱い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「相変わらずの状態が続くので心が晴れず、あきること」");
                                break;
                                case 2:System.out.println("ヒント:くたびれて気力が衰えること");
                                break;
                                case 3:System.out.println("ヒント:いやになること");
                                break;
                                case 4:System.out.println("ヒント:いやになるさま");
                                break;
                                case 5:System.out.println("ヒント:「することがなくて、時間を持て余すこと」");
                                break;
                                case 6:System.out.println("ヒント:つまらないこと");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("つまらないこと")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 22:{
                    System.out.println("動揺性歩行から性と歩行を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("動揺")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、弱い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「他からの作用で、動き揺れること」");
                                break;
                                case 2:System.out.println("ヒント:「転じて、気持ちなどが不安定になること」");
                                break;
                                case 3:System.out.println("ヒント:不安");
                                break;
                                case 4:System.out.println("ヒント:さわぎ");
                                break;
                                case 5:System.out.println("ヒント:心の○○を隠す");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でverärgernを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でverärgernを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 23:{
                    System.out.println("心配事から事を外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("心配")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、弱い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:おもいわずらうこと");
                                break;
                                case 2:System.out.println("ヒント:きがかり");
                                break;
                                case 3:System.out.println("ヒント:上手く運ぶように気を使って手配すること");
                                break;
                                case 4:System.out.println("ヒント:配慮");
                                break;
                                case 5:System.out.println("ヒント:きにかけてめんどうをみること");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でAngstを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でAngstを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                case 24:{
                    System.out.println("容認発音から発音外したものを何という？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("容認")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、弱い感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「それでよいとして、認めること」");
                                break;
                                case 2:System.out.println("ヒント:行動の自由を○○する");
                                break;
                                case 3:System.out.println("ヒント:許せる範囲と認めて許すこと");
                                break;
                                case 4:System.out.println("ヒント:複国籍○○");
                                break;
                                case 5:System.out.println("ヒント:副業○○");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でAnnahmeを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("ドイツ語でAnnahmeを意味する")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
                default:{
                    System.out.println("問題");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String decrease=scanaria(l);
                        if(decrease.equals("用語")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「所属に所属しており、位置に位置している」");
                                break;
                                case 1:System.out.println("ヒント:");
                                break;
                                case 2:System.out.println("ヒント:");
                                break;
                                case 3:System.out.println("ヒント:");
                                break;
                                case 4:System.out.println("ヒント:");
                                break;
                                case 5:System.out.println("ヒント:");
                                break;
                                case 6:System.out.println("ヒント:");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String decrease="0";
                        if(m.equals("")){
                            System.out.println("正解:"+pull(decrease));
                            break;
                        }
                    }
                }
                break;
            }
        }
    }
    public static void Squaredaria(String Squared) {
        System.out.println("乗算エリア");
        int e=0;
        String l="8";
        String hint[]=new String[100];
        lasthint(hint);
        while(e<2){
            e++;
            int a=new java.util.Random().nextInt(6);
            switch (a) {
                case 0:{
                    System.out.println("笑われるとコンプレックスから生み出されるものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Deadlysins=scanaria(l);
                        if(Deadlysins.equals("傲慢")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、七大罪に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「取得する経験値、熟練度、各能力値が大幅に上昇する代わりに好戦的になり許容量以上の経験値をため込んでしまう」");
                                break;
                                case 2:System.out.println("ヒント:高ぶって人を侮り見下す態度であること");
                                break;
                                case 3:System.out.println("ヒント:○○無礼");
                                break;
                                case 4:System.out.println("ヒント:調子づいて人を馬鹿にする");
                                break;
                                case 5:System.out.println("ヒント:ひとをみくびって礼儀を欠くこと");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でArroganzを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Deadlysins="0";
                        if(m.equals("ドイツ語でArroganzを意味する")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        }
                    }
                }    
                break;
                case 1:{
                    System.out.println("理性消失と本能的殺戮から生み出されるものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Deadlysins=scanaria(l);
                        if(Deadlysins.equals("憤怒")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、七大罪及び負の感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「最大で通常の10倍近くまで代償なくステータスを底上げすることが出来るが、やがて唯の狂戦士と化す」");
                                break;
                                case 2:System.out.println("ヒント:「つかみかからんばかりの恐ろしい形相で、激しく怒る事」");
                                break;
                                case 3:System.out.println("ヒント:○○の悪魔");
                                break;
                                case 4:System.out.println("ヒント:非道な行為に○○する");
                                break;
                                case 5:System.out.println("ヒント:○○の魔女");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でWutを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Deadlysins="0";
                        if(m.equals("ドイツ語でWutを意味する")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        }
                    }
                }
                break;
                case 2:{
                    System.out.println("周囲大幅消費と自己効率から生み出されるものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Deadlysins=scanaria(l);
                        if(Deadlysins.equals("怠惰")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、七大罪に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「精神に異常をきたすことは無く、皮肉が込められている」");
                                break;
                                case 2:System.out.println("ヒント:「つかみかからんばかりの恐ろしい形相で、激しく怒る事」");
                                break;
                                case 3:System.out.println("ヒント:なまけておりだらしないさま");
                                break;
                                case 4:System.out.println("ヒント:○○の悪魔");
                                break;
                                case 5:System.out.println("ヒント:魔女教大罪司教○○担当");
                                break;
                                case 6:System.out.println("ヒント:○○の魔女");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Deadlysins="0";
                        if(m.equals("○○の魔女")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        }
                    }
                }
                break;
                case 3:{
                    System.out.println("殺害相手からランダムに一部略奪と満たされない欲望から生み出されるものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Deadlysins=scanaria(l);
                        if(Deadlysins.equals("強欲")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、七大罪に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「eを加えた場合、錬金術で生み出されたメダルを体内に収納しているといずれはグリードへと堕ちていく」");
                                break;
                                case 2:System.out.println("ヒント:あくどいほど欲が張っている事");
                                break;
                                case 3:System.out.println("ヒント:「際限なく、何が何でも、自分の欲を満たそうとするさま」");
                                break;
                                case 4:System.out.println("ヒント:○○の悪魔");
                                break;
                                case 5:System.out.println("ヒント:○○の魔女");
                                break;
                                case 6:System.out.println("ヒント:魔女教大罪司教○○担当");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Deadlysins="0";
                        if(m.equals("魔女教大罪司教○○担当")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        }
                    }
                }
                break;
                case 4:{
                    System.out.println("あらゆるものを対象に食すことが可能と永久空腹から生み出されるものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Deadlysins=scanaria(l);
                        if(Deadlysins.equals("暴食")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、七大罪に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「永久空腹は克服可能であり、食したものはエネルギーとしてストックすることが出来る」");
                                break;
                                case 2:System.out.println("ヒント:暴飲○○");
                                break;
                                case 3:System.out.println("ヒント:○○する");
                                break;
                                case 4:System.out.println("ヒント:○○の魔女");
                                break;
                                case 5:System.out.println("ヒント:○○者");
                                break;
                                case 6:System.out.println("ヒント:○○の悪魔");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Deadlysins="0";
                        if(m.equals("○○の悪魔")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        }
                    }
                }
                break;
                case 5:{
                    System.out.println("相手に「催眠」「魅了」「洗脳」の状態異常を付与と激しい嫌悪感から生み出されるものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Deadlysins=scanaria(l);
                        if(Deadlysins.equals("色欲")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、七大罪に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「対象となった者は持ち主の意のままに操られるが、継続的に重ね掛けが必要となる」");
                                break;
                                case 2:System.out.println("ヒント:性的な欲望");
                                break;
                                case 3:System.out.println("ヒント:情欲");
                                break;
                                case 4:System.out.println("ヒント:○○の悪魔");
                                break;
                                case 5:System.out.println("ヒント:色情と利欲");
                                break;
                                case 6:System.out.println("ヒント:ドイツ語でLustを意味する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Deadlysins="0";
                        if(m.equals("ドイツ語でLustを意味する")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        }
                    }
                }
                break;
                default:{
                    System.out.println("問題");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Deadlysins=scanaria(l);
                        if(Deadlysins.equals("用語")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「所属に所属しており、位置に位置している」");
                                break;
                                case 1:System.out.println("ヒント:");
                                break;
                                case 2:System.out.println("ヒント:");
                                break;
                                case 3:System.out.println("ヒント:");
                                break;
                                case 4:System.out.println("ヒント:");
                                break;
                                case 5:System.out.println("ヒント:");
                                break;
                                case 6:System.out.println("ヒント:");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Deadlysins="0";
                        if(m.equals("")){
                            System.out.println("正解:"+Squared(Deadlysins));
                            break;
                        }
                    }
                }
                break;
            }
        }
    }
    public static void Multiplicationdivisionaria(String Multiplicationdivision) {
        System.out.println("乗算除算エリア");
        int f=0;
        String l="9";
        String hint[]=new String[100];
        lasthint(hint);
        while(f<2){
            int b=new java.util.Random().nextInt(8);
            f++;
            switch (b) {
                case 0:{
                    System.out.println("死者蘇生と禁忌から生み出され、自己を省くものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Virtues=scanaria(l);
                        if(Virtues.equals("慈悲")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「行動に所属しており、七美徳に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「死亡から数分程度でなければ使用できず、使用するごとに禁忌レベルが上昇してきます」");
                                break;
                                case 2:System.out.println("ヒント:「仏・菩薩が人々をあわれみ、楽しみを与え、苦しみを取り除くこと」");
                                break;
                                case 3:System.out.println("ヒント:「いつくしみ、あわれむこと」");
                                break;
                                case 4:System.out.println("ヒント:○○の天使王");
                                break;
                                case 5:System.out.println("ヒント:○○深い");
                                break;
                                case 6:System.out.println("ヒント:「他者の苦しみを理解し、その苦しみを和らげることを心から願う感情や態度を指します」");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Virtues="0";
                        if(m.equals("「他者の苦しみを理解し、その苦しみを和らげることを心から願う感情や態度を指します」")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }
                    }
                }    
                break;
                case 1:{
                    System.out.println("死亡回避と防御・抵抗の能力上昇と耐性系熟練度補正から生み出され、我慢を省くものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Virtues=scanaria(l);
                        if(Virtues.equals("忍耐")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「行動に所属しており、七美徳に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「体力を1残し、生存する」");
                                break;
                                case 2:System.out.println("ヒント:「苦しさ、辛さ、悲しさなどを耐え忍ぶこと」");
                                break;
                                case 3:System.out.println("ヒント:○○力");
                                break;
                                case 4:System.out.println("ヒント:○○の天使");
                                break;
                                case 5:System.out.println("ヒント:○○強い");
                                break;
                                case 6:System.out.println("ヒント:じっと耐え忍ぶこと");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Virtues="0";
                        if(m.equals("じっと耐え忍ぶこと")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }
                    }
                }
                break;
                case 2:{
                    System.out.println("魂移す侵食乗っ取りと半分不死から生み出され、他者の意思を省くものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Virtues=scanaria(l);
                        if(Virtues.equals("勤勉")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「行動に所属しており、七美徳に位置している」");
                                break;
                                case 1:System.out.println("ヒント:一日も欠かすことなく毎日同じことを繰り返す");
                                break;
                                case 2:System.out.println("ヒント:仕事や勉強に一所懸命に励むこと");
                                break;
                                case 3:System.out.println("ヒント:○○家");
                                break;
                                case 4:System.out.println("ヒント:良く働き、学ぶこと");
                                break;
                                case 5:System.out.println("ヒント:ドイツ語でSorgfaltを意味する");
                                break;
                                case 6:System.out.println("ヒント:たゆまずに一所懸命にあることを続けていく様");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Virtues="0";
                        if(m.equals("たゆまずに一所懸命にあることを続けていく様")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }
                    }
                }
                break;
                case 3:{
                    System.out.println("自身を中心に自己及び味方へ体力超速回復と寄付から生み出され、ストックを省くものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Virtues=scanaria(l);
                        if(Virtues.equals("救恤")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「行動に所属しており、七美徳に位置している」");
                                break;
                                case 1:System.out.println("ヒント:最下級回復術師");
                                break;
                                case 2:System.out.println("ヒント:「貧乏人・被災者等を救い、恵むこと」");
                                break;
                                case 3:System.out.println("ヒント:困っている人に見舞いの金品などを与えて救うこと");
                                break;
                                case 4:System.out.println("ヒント:万人の○○");
                                break;
                                case 5:System.out.println("ヒント:ドイツ語でErleichtterungを意味する");
                                break;
                                case 6:System.out.println("ヒント:○○の王");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Virtues="0";
                        if(m.equals("○○の王")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }
                    }
                }
                break;
                case 4:{
                    System.out.println("前世の記憶保持状態での転生可能と実質不死から生み出され、不正を省くものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Virtues=scanaria(l);
                        if(Virtues.equals("節制")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「行動に所属しており、七美徳に位置している」");
                                break;
                                case 1:System.out.println("ヒント:切り詰めて行動している");
                                break;
                                case 2:System.out.println("ヒント:「欲望におぼれて度を超すことが無いように、適度に慎むこと」");
                                break;
                                case 3:System.out.println("ヒント:規律正しく統率のとれている事");
                                break;
                                case 4:System.out.println("ヒント:○○生活");
                                break;
                                case 5:System.out.println("ヒント:ドイツ語でMäßigkeitを意味する");
                                break;
                                case 6:System.out.println("ヒント:○○の天使");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Virtues="0";
                        if(m.equals("○○の天使")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }
                    }
                }
                break;
                case 5:{
                    System.out.println("魂を消費して神と同等の力を得ると対等な立場から生み出され、不快感を省くものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Virtues=scanaria(l);
                        if(Virtues.equals("謙譲")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「行動に所属しており、七美徳に位置している」");
                                break;
                                case 1:System.out.println("ヒント:魂魄の一部を神へと渡すこと");
                                break;
                                case 2:System.out.println("ヒント:へりくだること");
                                break;
                                case 3:System.out.println("ヒント:謙遜");
                                break;
                                case 4:System.out.println("ヒント:○○の美徳");
                                break;
                                case 5:System.out.println("ヒント:ドイツ語でDemutを意味する");
                                break;
                                case 6:System.out.println("ヒント:○○語");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Virtues="0";
                        if(m.equals("○○語")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }
                    }
                }
                break;
                case 6:{
                    System.out.println("自身の持つ神性領域を拡張すると強力な結界を展開するから生み出され、性的な関係を省くものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Virtues=scanaria(l);
                        if(Virtues.equals("純潔")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「行動に所属しており、七美徳に位置している」");
                                break;
                                case 1:System.out.println("ヒント:ピュアである");
                                break;
                                case 2:System.out.println("ヒント:肉体や心が汚れていない事");
                                break;
                                case 3:System.out.println("ヒント:「心身にけがれがなく、清らかな事」");
                                break;
                                case 4:System.out.println("ヒント:赤いフリージアの花言葉");
                                break;
                                case 5:System.out.println("ヒント:ドイツ語でReinheitを意味する");
                                break;
                                case 6:System.out.println("ヒント:スズランの花言葉");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Virtues="0";
                        if(m.equals("スズランの花言葉")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }
                    }
                }
                break;
                case 7:{
                    System.out.println("全情報閲覧とマッピングと追跡と魔道の極みと星魔から生み出され、拒否を省くものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Virtues=scanaria(l);
                        if(Virtues.equals("叡智")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「知識に所属しており、感情、七美徳、七大罪のいずれにも位置しない」");
                                break;
                                case 1:System.out.println("ヒント:支配者権限に気まぐれで追加されたものである");
                                break;
                                case 2:System.out.println("ヒント:深遠な道理を知り得る優れた知恵");
                                break;
                                case 3:System.out.println("ヒント:物事の真実在の理性的、悟性的認識");
                                break;
                                case 4:System.out.println("ヒント:○○の王");
                                break;
                                case 5:System.out.println("ヒント:ドイツ語でWeisheitを意味する");
                                break;
                                case 6:System.out.println("ヒント:人類の○○");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Virtues="0";
                        if(m.equals("人類の○○")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }
                    }
                }
                break;
                default:{
                    System.out.println("問題");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Virtues=scanaria(l);
                        if(Virtues.equals("用語")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「所属に所属しており、位置に位置している」");
                                break;
                                case 1:System.out.println("ヒント:");
                                break;
                                case 2:System.out.println("ヒント:");
                                break;
                                case 3:System.out.println("ヒント:");
                                break;
                                case 4:System.out.println("ヒント:");
                                break;
                                case 5:System.out.println("ヒント:");
                                break;
                                case 6:System.out.println("ヒント:");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Virtues="0";
                        if(m.equals("")){
                            System.out.println("正解:"+Multiplicationdivision(Virtues));
                            break;
                        }
                    }
                }
                break;
            }
        }
    }
    public static void arithmeticoperationaria(String arithmeticoperation) {
        System.out.println("演算エリア");
        String l="10";
        String hint[]=new String[100];
        lasthint(hint);
        for(int g=0;g<2;g++){
            int h=new java.util.Random().nextInt(6);
            switch (h) {
                case 0:{
                    System.out.println("深い悲しみと憎悪から至り、一つを除いてあらゆる感情が鎮静されるものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Perfectconclusion=scanaria(l);
                        if(Perfectconclusion.equals("悪意")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        }else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、負の感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「他の存在や物事に対して抱く悪い感情、または見方」");
                                break;
                                case 2:System.out.println("ヒント:わるぎ");
                                break;
                                case 3:System.out.println("ヒント:○○がある");
                                break;
                                case 4:System.out.println("ヒント:無意識の○○");
                                break;
                                case 5:System.out.println("ヒント:○○の連鎖は止められない");
                                break;
                                case 6:System.out.println("ヒント:「他の存在を憎み、害を加えようとする気持ち」");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Perfectconclusion="0";
                        if(m.equals("「他の存在を憎み、害を加えようとする気持ち」")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        }
                    }
                }    
                break;
                case 1:{
                    System.out.println("殺し合う儀式と秘めた戦求本能から至り、全く同じものでは話にならないものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Perfectconclusion=scanaria(l);
                        if(Perfectconclusion.equals("闘争")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        }else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、負の感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:たたかうこと");
                                break;
                                case 2:System.out.println("ヒント:あらそい");
                                break;
                                case 3:System.out.println("ヒント:○○本能");
                                break;
                                case 4:System.out.println("ヒント:○○の女神");
                                break;
                                case 5:System.out.println("ヒント:ドイツ語でKampfを意味する");
                                break;
                                case 6:System.out.println("ヒント:○○を求める");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Perfectconclusion="0";
                        if(m.equals("○○を求める")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        }
                    }
                }
                break;
                case 2:{
                    System.out.println("愛も欲も自分の中と気付けない存在が謳うから至り、心の中を探すものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Perfectconclusion=scanaria(l);
                        if(Perfectconclusion.equals("殺意")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        }else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、負の感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:存在を殺そうとする意志");
                                break;
                                case 2:System.out.println("ヒント存在を死に至らしめる危険性の高い行為をすることの認識");
                                break;
                                case 3:System.out.println("ヒント:どうしようもなく相手に対して苛立ちなどを覚えた際に芽生える感情");
                                break;
                                case 4:System.out.println("ヒント:○○の波動");
                                break;
                                case 5:System.out.println("ヒント:スノードロップの花言葉より「貴方の死を望みます」");
                                break;
                                case 6:System.out.println("ヒント:○○の衝動");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Perfectconclusion="0";
                        if(m.equals("○○の衝動")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        }
                    }
                }
                break;
                case 3:{
                    System.out.println("個体の減少と星から存在しなくなるから至り、バランスが破損するものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Perfectconclusion=scanaria(l);
                        if(Perfectconclusion.equals("絶滅")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        }else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、負の感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:絶え滅びること");
                                break;
                                case 2:System.out.println("ヒント:絶やし滅ぼすこと");
                                break;
                                case 3:System.out.println("ヒント:地球上から永遠にいなくなってしますこと");
                                break;
                                case 4:System.out.println("ヒント:○○危惧種");
                                break;
                                case 5:System.out.println("ヒント:レッドリスト");
                                break;
                                case 6:System.out.println("ヒント:人類が○○する");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Perfectconclusion="0";
                        if(m.equals("人類が○○する")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        }
                    }
                }
                break;
                case 4:{
                    System.out.println("死亡するフラグと成長するスピード速遅から至り、創造の先にあるものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Perfectconclusion=scanaria(l);
                        if(Perfectconclusion.equals("破滅")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        }else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、負の感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:存在価値を失うまでに駄目になる事");
                                break;
                                case 2:System.out.println("ヒント:存在が身を滅ぼすこと");
                                break;
                                case 3:System.out.println("ヒント:○○フラグ");
                                break;
                                case 4:System.out.println("ヒント:○○の本");
                                break;
                                case 5:System.out.println("ヒント:ドイツ語でRuineを意味する");
                                break;
                                case 6:System.out.println("ヒント:○○的思考");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Perfectconclusion="0";
                        if(m.equals("○○的思考")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        }
                    }
                }
                break;
                case 5:{
                    System.out.println("破局的な被害を受けると失い陥った運命から至り、回避したいと思うものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Perfectconclusion=scanaria(l);
                        if(Perfectconclusion.equals("滅亡")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        }else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「感情に所属しており、負の感情に位置している」");
                                break;
                                case 1:System.out.println("ヒント:滅びること");
                                break;
                                case 2:System.out.println("ヒント:絶えてなくなる事");
                                break;
                                case 3:System.out.println("ヒント:○○迅雷");
                                break;
                                case 4:System.out.println("ヒント:○○迅雷.net");
                                break;
                                case 5:System.out.println("ヒント:ドイツ語でZerstörungを意味する");
                                break;
                                case 6:System.out.println("ヒント:睡蓮の花言葉");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Perfectconclusion="0";
                        if(m.equals("睡蓮の花言葉")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        }
                    }
                }
                break;
                default:{
                    System.out.println("問題");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Perfectconclusion=scanaria(l);
                        if(Perfectconclusion.equals("用語")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「所属に所属しており、位置に位置している」");
                                break;
                                case 1:System.out.println("ヒント:");
                                break;
                                case 2:System.out.println("ヒント:");
                                break;
                                case 3:System.out.println("ヒント:");
                                break;
                                case 4:System.out.println("ヒント:");
                                break;
                                case 5:System.out.println("ヒント:");
                                break;
                                case 6:System.out.println("ヒント:");
                                break;
                            }
                        }
                    }
                    for(int k=0;k<hint.length;k++){
                        String m=hint[k];
                        String Perfectconclusion="0";
                        if(m.equals("")){
                            System.out.println("正解:"+arithmeticoperation(Perfectconclusion));
                            break;
                        }
                    }
                }
                break;
            }
        }
    }
    public static void conversionaria(String conversion) {
        System.out.println("変換エリア");
        String l="11";
        String hint[]=new String[100];
        lasthint(hint);
        for(int j=0;j<2;j++){
            int k=new java.util.Random().nextInt(30);
            switch (k) {
                case 0:{
                    System.out.println("「それは聖なる力、それは未知への冒険、そしてそれは勇気の証」を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("魔法")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「力に所属しており、概念に位置している」");
                                break;
                                case 1:System.out.println("ヒント:魔力等のエネルギーを使用して不思議なことを起こさせる術");
                                break;
                                case 2:System.out.println("ヒント:「蜘蛛ですが、なにか」の世界において魔術をシステム（魔力を「スキル」により変化させて現象として確立したもの）を通して簡略化したもの");
                                break;
                                case 3:System.out.println("ヒント:○○陣");
                                break;
                                case 4:System.out.println("ヒント:ホグワーツ○○魔術学校");
                                break;
                                case 5:System.out.println("ヒント:治癒○○の間違った使い方");
                                break;
                                case 6:System.out.println("ヒント:○○科高校の劣等生");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("○○科高校の劣等生")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }           
                break;
                case 1:{
                    System.out.println("輝く精神を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("キラメンタル")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「精神力に所属しており、概念に位置している」");
                                break;
                                case 1:System.out.println("ヒント:魅力や才能の源とされる輝く精神力");
                                break;
                                case 2:System.out.println("ヒント:ジャメンタルの対となる");
                                break;
                                case 3:System.out.println("ヒント:キラメイジャーに変身する者に求められる素質");
                                break;
                                case 4:System.out.println("ヒント:魔進戦隊キラメイジャーに登場する用語の1つ");
                                break;
                                case 5:System.out.println("ヒント:キラメイストーンと共鳴する強靭な輝くの精神");
                                break;
                                case 6:System.out.println("ヒント:○○○○○○湧いてきた");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("○○○○○○湧いてきた")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 2:{
                    System.out.println("自分だけの何かを変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("ガッチャ!")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「行動に所属しており、概念に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「どでかい夢」とか「やった！」「掴んだ！」というような感じ");
                                break;
                                case 2:System.out.println("ヒント:一ノ瀬宝太郎は錬金術に見出した");
                                break;
                                case 3:System.out.println("ヒント:仮面ライダーガッチャード/一ノ瀬宝太郎の口癖");
                                break;
                                case 4:System.out.println("ヒント:仮面ライダーガッチャードに登場する用語の1つ");
                                break;
                                case 5:System.out.println("ヒント:上手く行かなかったときはノー○○○○○");
                                break;
                                case 6:System.out.println("ヒント:「○○○○○を追い求め、創作料理を作ったりしている」");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("「○○○○○を追い求め、創作料理を作ったりしている」")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 3:{
                    System.out.println("忍者に対して抱く各々の心の在り方や精神の持ち方と言った精神力を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("忍タリティ")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「精神力に所属しており、概念に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「２ディメンションの術を使用したのち必殺技として○○○○○爆裂波を放つ」");
                                break;
                                case 2:System.out.println("ヒント:忍者の力の源ともいうべきもの");
                                break;
                                case 3:System.out.println("ヒント:手裏剣戦隊ニンニンジャーにて登場する用語の1つ");
                                break;
                                case 4:System.out.println("ヒント:高めろ！○○○○○‼");
                                break;
                                case 5:System.out.println("ヒント:○○○○○絵巻");
                                break;
                                case 6:System.out.println("ヒント:喪失すると忍びとしての資格を失うことと同義である");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("喪失すると忍びとしての資格を失うことと同義である")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 4:{
                    System.out.println("「創る、形成する」を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("ビルド")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「虚構の存在に所属しており、概念に位置している」");
                                break;
                                case 1:System.out.println("ヒント:同じ肉体で顔の違う科学者が違う結論を導いた者の姿");
                                break;
                                case 2:System.out.println("ヒント:○○○ドライバー");
                                break;
                                case 3:System.out.println("ヒント:仮面ライダー○○○で登場する用語の1つ");
                                break;
                                case 4:System.out.println("ヒント:プロジェクト・○○○");
                                break;
                                case 5:System.out.println("ヒント:○○○アップ");
                                break;
                                case 6:System.out.println("ヒント:○○○が創る明日");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("○○○が創る明日")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 5:{
                    System.out.println("愛と平和を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("ラブ＆ピース")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「概念に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「他者への深い感情や情熱を指し、戦争や紛争がない状態や調和を示す」");
                                break;
                                case 2:System.out.println("ヒント:○○○○○○の世界へ");
                                break;
                                case 3:System.out.println("ヒント:4人が仮面ライダーとして戦う理由の一つ");
                                break;
                                case 4:System.out.println("ヒント:仮面ライダービルドに登場する用語の1つ");
                                break;
                                case 5:System.out.println("ヒント:葛城忍が科学者になった理由");
                                break;
                                case 6:System.out.println("ヒント:愛と平和");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("愛と平和")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 6:{
                    System.out.println("『「勇気(brave)」だけでなく滅びた小惑星にはなかったもので、共に燃え上がり、絶望を乗り越える人間の魂とされる心の力』を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("ブレイブ")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「精神力に所属しており、概念に位置している」");
                                break;
                                case 1:System.out.println("ヒント:勇敢であることや恐れを知らぬこと");
                                break;
                                case 2:System.out.println("ヒント:○○○○イン");
                                break;
                                case 3:System.out.println("ヒント:真の地球のメロディを聴き、歌うことで○○○○が回復、新たに生み出される");
                                break;
                                case 4:System.out.println("ヒント:獣電戦隊キョウリュウジャーに登場する用語の1つ");
                                break;
                                case 5:System.out.println("ヒント:キョウリュウジャー関連でアツいこと等がある");
                                break;
                                case 6:System.out.println("ヒント:強き竜の者であるキョウリュウジャーに変身するために必要な力");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("強き竜の者であるキョウリュウジャーに変身するために必要な力")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 7:{
                    System.out.println("想像力を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("イマジネーション")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「力に所属しており、概念に位置している」");
                                break;
                                case 1:System.out.println("ヒント:夢見る力");
                                break;
                                case 2:System.out.println("ヒント:想像する力");
                                break;
                                case 3:System.out.println("ヒント:多くの場合は子供にしか宿っておらず、大人になるとそのほとんどが喪失してしまう");
                                break;
                                case 4:System.out.println("ヒント:列車戦隊トッキュウジャーに登場する用語の1つ");
                                break;
                                case 5:System.out.println("ヒント:これを動力とするレインボーラインの列車がある");
                                break;
                                case 6:System.out.println("ヒント:トッキュウジャーに変身するために必要な力");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("トッキュウジャーに変身するために必要な力")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 8:{
                    System.out.println("マイペースに行くを変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("モカってる")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「行動に所属しており、概念に位置している」");
                                break;
                                case 1:System.out.println("ヒント:モカちゃんの感性で決まる");
                                break;
                                case 2:System.out.println("ヒント:モカちゃんらしい");
                                break;
                                case 3:System.out.println("ヒント:「興味がわかない物にはとことん無関心だが、好きな人の為には一所懸命になれる様」");
                                break;
                                case 4:System.out.println("ヒント:BanGDream!ガールズバンドパーティーに登場する用語の1つ");
                                break;
                                case 5:System.out.println("ヒント:造語である");
                                break;
                                case 6:System.out.println("ヒント:冗談めかした言動が多いがひょうひょうとした態度の裏側には強く大きな情熱を抱えている");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("冗談めかした言動が多いがひょうひょうとした態度の裏側には強く大きな情熱を抱えている")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 9:{
                    System.out.println("頑張っているを変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("ツグってる")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「行動に所属しており、概念に位置している」");
                                break;
                                case 1:System.out.println("ヒント:「普通が故に努力家で前向き、少しのことではめげないさま」");
                                break;
                                case 2:System.out.println("ヒント:造語");
                                break;
                                case 3:System.out.println("ヒント:○○○ともいう");
                                break;
                                case 4:System.out.println("ヒント:BanGDream!ガールズバンドパーティーに登場する用語の1つ");
                                break;
                                case 5:System.out.println("ヒント:○○ってみよ-!");
                                break;
                                case 6:System.out.println("ヒント:頑張っているさま");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("頑張っているさま")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 10:{
                    System.out.println("可愛いものに目がない様を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("ノアってる")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「行動に所属しており、概念に位置している」");
                                break;
                                case 1:System.out.println("ヒント:可愛いものに対して暴走する様");
                                break;
                                case 2:System.out.println("ヒント:造語");
                                break;
                                case 3:System.out.println("ヒント:かわいいものに目がない");
                                break;
                                case 4:System.out.println("ヒント:D4DJ grovymixに登場する用語の1つ");
                                break;
                                case 5:System.out.println("ヒント:好奇心が強く知識も豊富で、興味のあることには饒舌になる");
                                break;
                                case 6:System.out.println("ヒント:「カワイイ」という概念への情景がある");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("「カワイイ」という概念への情景がある")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 11:{
                    System.out.println("自分を認めてくれる相手には甘えていくが、そうでない相手にはガードが堅い様を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("むにってる")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「行動に所属しており、概念に位置している」");
                                break;
                                case 1:System.out.println("ヒント:幼馴染に対して愛が重い行動を魅せる");
                                break;
                                case 2:System.out.println("ヒント:造語");
                                break;
                                case 3:System.out.println("ヒント:○○○○○時は不機嫌だったりする");
                                break;
                                case 4:System.out.println("ヒント:D4DJ grovymixに登場する用語の1つ");
                                break;
                                case 5:System.out.println("ヒント:ネット上で「絵師」として注目を集めている本人");
                                break;
                                case 6:System.out.println("ヒント:よさがわからないやつはミュートする");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("よさがわからないやつはミュートする")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 12:{
                    System.out.println("感情を持つAI（機械族）が感情を持たないAI（機械族）のような行動を取る様を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("ルミナってる")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「行動に所属しており、概念に位置している」");
                                break;
                                case 1:System.out.println("ヒント:AI故に単調な行動を取る様");
                                break;
                                case 2:System.out.println("ヒント:造語");
                                break;
                                case 3:System.out.println("ヒント:ネオに心を届けるために存在する");
                                break;
                                case 4:System.out.println("ヒント:心を得た存在");
                                break;
                                case 5:System.out.println("ヒント:歌姫アリアの現身に近い存在");
                                break;
                                case 6:System.out.println("ヒント:演算結果に順応なAI");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("演算結果に順応なAI")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 13:{
                    System.out.println("何とも言い表せない素敵な気持ちを変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("エモい")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:感情に所属している");
                                break;
                                case 1:System.out.println("ヒント:ある対象に対して感情が変化した時に使用される");
                                break;
                                case 2:System.out.println("ヒント:感動を表す");
                                break;
                                case 3:System.out.println("ヒント:俗語");
                                break;
                                case 4:System.out.println("ヒント:切なさやなつかしさを含む場面が多い");
                                break;
                                case 5:System.out.println("ヒント:○○○デザイン");
                                break;
                                case 6:System.out.println("ヒント:感情的なさま");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("感情的なさま")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 14:{
                    System.out.println("小さいもの、弱いものなどに心惹かれる気持ちを抱く様を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("可愛い")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:感情に所属している");
                                break;
                                case 1:System.out.println("ヒント:「（小さくて）愛らしい、小さい、同情を誘うばかりに（痛々しく）かわいそうだ」");
                                break;
                                case 2:System.out.println("ヒント:○○○○アイテム");
                                break;
                                case 3:System.out.println("ヒント:他と比べて小さいさま");
                                break;
                                case 4:System.out.println("ヒント:かわいそうだ");
                                break;
                                case 5:System.out.println("ヒント:共感を高め、信頼に出来る関係性を形成する為");
                                break;
                                case 6:System.out.println("ヒント:本気で対象となる事物を○○○○と思っていない場合に用いる");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("本気で対象となる事物を○○○○と思っていない場合に用いる")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 15:{
                    System.out.println("素晴らしい、最高を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("尊い")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:感情に所属している");
                                break;
                                case 1:System.out.println("ヒント:価値が高い");
                                break;
                                case 2:System.out.println("ヒント:大切だ");
                                break;
                                case 3:System.out.println("ヒント:貴重だ");
                                break;
                                case 4:System.out.println("ヒント:身分が高い");
                                break;
                                case 5:System.out.println("ヒント:敬うべきだ");
                                break;
                                case 6:System.out.println("ヒント:「本来の意味を超越するほど素晴らしく、他に比べるものがないくらい好きである」");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("「本来の意味を超越するほど素晴らしく、他に比べるものがないくらい好きである」")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 16:{
                    System.out.println("時間が重なってできたもの、特定の事象を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("記憶")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:物事を忘れずに覚えている事");
                                break;
                                case 2:System.out.println("ヒント:覚えておくこと");
                                break;
                                case 3:System.out.println("ヒント:「過去の経験の内容を保持し、後でそれを思い出すこと」");
                                break;
                                case 4:System.out.println("ヒント:○○障害");
                                break;
                                case 5:System.out.println("ヒント:ガイアメモリに内包されるもの");
                                break;
                                case 6:System.out.println("ヒント:地球の本棚に○○されているもの");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("地球の本棚に○○されているもの")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 17:{
                    System.out.println("存在の数だけ存在する、理想の具現化、偽善、正しい道理を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("正義")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:行動に所属しており、概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:この概念同士で対立する");
                                case 2:System.out.println("ヒント:神エレボスが言った「脆き者よ、汝の名は○○○なり」");
                                break;
                                case 3:System.out.println("ヒント:人間の社会的関係において実現されるべき究極的な価値");
                                break;
                                case 4:System.out.println("ヒント:人間の対他的関係の規律に関わる法的な価値をさす");
                                break;
                                case 5:System.out.println("ヒント:弱者を救い、悪者を懲らしめる人");
                                break;
                                case 6:System.out.println("ヒント:○○は巡る");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("○○は巡る")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 18:{
                    System.out.println("姓名も社会も文明も全て無に還すを変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("絶対悪")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:行動に所属しており、概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:共犯者のみが偉業と称えた行動");
                                break;
                                case 2:System.out.println("ヒント:○○的な○のこと");
                                break;
                                case 3:System.out.println("ヒント:「本人は悪い事と全く思っていないが、私利私欲や興味関心のためにどう考えても他人にとっては迷惑極まりない行為を平然と行う」");
                                break;
                                case 4:System.out.println("ヒント:憎まれることこそ悪の本懐");
                                break;
                                case 5:System.out.println("ヒント:「悪いことをしたくて悪事を働き、なおかつそこに何も思うところがない」");
                                break;
                                case 6:System.out.println("ヒント:必要悪とは異なる");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("必要悪とは異なる")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 19:{
                    System.out.println("運命共同体を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("バンド")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:集団に所属しており、概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:演奏に不調なメンバーが全て揃っている状態");
                                break;
                                case 2:System.out.println("ヒント:一般にロックを演奏する事を目的");
                                break;
                                case 3:System.out.println("ヒント:通信における帯域幅");
                                break;
                                case 4:System.out.println("ヒント:通信路容量");
                                break;
                                case 5:System.out.println("ヒント:バンドリでは12以上の○○○が存在する");
                                break;
                                case 6:System.out.println("ヒント:次世代ガールズ○○○プロジェクト");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("次世代ガールズ○○○プロジェクト")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 20:{
                    System.out.println("「ダンス・クラブやディスコでレコードを選択し、プレーする人」、存在と音楽を繋ぐのを変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("DJ")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:職業に所属しており、概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:バンドやユニットに参加している人もいる");
                                break;
                                case 2:System.out.println("ヒント:ラジオ○○とクラブ○○の2種類の職業がある");
                                break;
                                case 3:System.out.println("ヒント:○○ミキサー");
                                break;
                                case 4:System.out.println("ヒント:トラックメイカーも兼ねる○○は、○○Remix");
                                break;
                                case 5:System.out.println("ヒント:D○○400ハピアラモデル");
                                break;
                                case 6:System.out.println("ヒント:「○○*アニメ*ゲームでおくる、全く新しいメディアミックスプロジェクトD4○○」");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("「○○*アニメ*ゲームでおくる、全く新しいメディアミックスプロジェクトD4○○」")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 21:{
                    System.out.println("多数の要素が集ま手まとまりを持った組織や体系のことを変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("システム")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:相互に影響をおよぼしあう要素から構成される");
                                break;
                                case 2:System.out.println("ヒント:まとまりや仕組みの全体");
                                break;
                                case 3:System.out.println("ヒント:AI○○○○");
                                break;
                                case 4:System.out.println("ヒント:目的を遂行するための体系や組織の意味");
                                break;
                                case 5:System.out.println("ヒント:「コンピュータ分野、自然科学分野などを中心に幅広い分野で使われる」");
                                break;
                                case 6:System.out.println("ヒント:対義語として部品や要素を表す「モジュール」「パーツ」がある");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("対義語として部品や要素を表す「モジュール」「パーツ」がある")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 22:{
                    System.out.println("非常に稀有な「才能」たる転職に関連した能力を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("技能")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:力に所属しており、概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:あることを行うための技術的な能力");
                                break;
                                case 2:System.out.println("ヒント:ドイツ語でFähigkeitを意味する");
                                break;
                                case 3:System.out.println("ヒント:「物を作る仕事などに関し、それを巧みに（見事に）してのけることが出来る腕前」");
                                break;
                                case 4:System.out.println("ヒント:表面的な召喚ボーナスは言語理解と錬成");
                                break;
                                case 5:System.out.println("ヒント:潜在能力は○○の個数の分だけ分散する");
                                break;
                                case 6:System.out.println("ヒント:「魔物肉を直接食し、肉体を回復することで取得出来、取得者が出来る項目が増加することで派生として現れる」");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("「魔物肉を直接食し、肉体を回復することで取得出来、取得者が出来る項目が増加することで派生として現れる」")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 23:{
                    System.out.println("「攻撃・防御の正確さ、精密さ」を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("技術")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:方法に所属しており、概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:巧みに行う技・技巧・技芸");
                                break;
                                case 2:System.out.println("ヒント:ドイツ語でTechnologieを意味する");
                                break;
                                case 3:System.out.println("ヒント:「科学の原理を（産業や医療・事務などの活動に）役立てて、物を生産したり組織したりするしかた・わざ」");
                                break;
                                case 4:System.out.println("ヒント:物事を巧みに（能率的に）行う技");
                                break;
                                case 5:System.out.println("「ヒント:スナイパーを除いて○○のある隊員は戦闘能力の高い人物が多く、○○の高さはその隊員の強さに影響している事が多いです。」");
                                break;
                                case 6:System.out.println("ヒント:からめ手を得意とする隊員が特殊○○が高い");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("からめ手を得意とする隊員が特殊○○が高い")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 24:{
                    System.out.println("「8種の系統を持ち、神聖力を消費する」を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("神聖術")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:力に所属しており、概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:「暗黒術とも呼ばれ、神聖力或いは空間リソースと呼ばれるものを消費する」");
                                break;
                                case 2:System.out.println("ヒント:システムコールで始まる");
                                break;
                                case 3:System.out.println("ヒント:SAOアリシゼーション編に出てくる用語の1つである");
                                break;
                                case 4:System.out.println("ヒント:神器が宿した記憶を開放する超高等○○○");
                                break;
                                case 5:System.out.println("ヒント:武装完全支配術、記憶開放術が含まれる");
                                break;
                                case 6:System.out.println("ヒント:全8種存在する");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("全8種存在する")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 25:{
                    System.out.println("歌を歌う事を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("歌唱")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:行動に所属しており、概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:声を用いて音楽を作り出すことをいう");
                                break;
                                case 2:System.out.println("ヒント:ドイツ語でSingenを意味する");
                                break;
                                case 3:System.out.println("ヒント:「調の使用、リズム、持続音など様々な発声技術によって通常の音声を強化することで行われる」");
                                break;
                                case 4:System.out.println("ヒント:○○を行う人を歌手と言う");
                                break;
                                case 5:System.out.println("ヒント:異なる音程の声を歌う歌手による○○団");
                                break;
                                case 6:System.out.println("ヒント:AI○○ソフトが存在している");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("AI○○ソフトが存在している")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 26:{
                    System.out.println("分からないことにルールを探す地道な努力を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("科学")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:学問に所属しており、概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:発達しすぎた○○は魔法と区別がつかないと言われる");
                                break;
                                case 2:System.out.println("ヒント:一定の目的・方法のもとに種種の事象を研究する認識活動");
                                break;
                                case 3:System.out.println("ヒント:その成果としての体系知識");
                                break;
                                case 4:System.out.println("ヒント:自然○○だけを指す場合もある");
                                break;
                                case 5:System.out.println("ヒント:日本○○未来館");
                                break;
                                case 6:System.out.println("ヒント:○○知識");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("○○知識")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 27:{
                    System.out.println("音による芸術、器楽と声楽がある、人間に秘められた力を開放するものを変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("音楽")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:学問に所属しており、概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:音による時間の表現");
                                break;
                                case 2:System.out.println("ヒント:○○の要素には、リズム、メロディー、ハーモニ―の3要素をもとに、主題、形式、調性、拍子、テンポ、楽器によって構成されます");
                                break;
                                case 3:System.out.println("ヒント:直接心身に影響するものと、○○そのものの基盤として間接的に影響するものがあります");
                                break;
                                case 4:System.out.println("ヒント:バンドリ！オフィシャルバンドスコアが登場している");
                                break;
                                case 5:System.out.println("ヒント:D4DJgrovymixでは原曲のボーカルでリズムゲームが出来る");
                                break;
                                case 6:System.out.println("ヒント:Remixすれば曲の印象が変わる");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("Remixすれば曲の印象が変わる")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 28:{
                    System.out.println("時空全体、前後左右上下に広がる空間と過去から未来に伸びる時間をひっくるめたもの、「共感覚によって曲が変わる度に会場全体の音、人の気持ちの色が変わる」を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("宇宙")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:秩序ある統一体としての世界");
                                break;
                                case 2:System.out.println("ヒント:あらゆる天体の存在する空間");
                                break;
                                case 3:System.out.println("ヒント:ビッグバンによって生まれた");
                                break;
                                case 4:System.out.println("ヒント:物体が○○の果てまで飛び去ることが出来る初速度の最小値を第二○○速度");
                                break;
                                case 5:System.out.println("ヒント:コズミックエナジーが存在する空間");
                                break;
                                case 6:System.out.println("ヒント:○○で唯一の”魂のパートナー”「ソウルバディ」");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("○○で唯一の”魂のパートナー”「ソウルバディ」")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                case 29:{
                    System.out.println("星の理を捻じ曲げる理法術と呼ばれる魔法の名を示す、下界に神の居る時代を変換したものは何？");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("神代")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }else {
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:概念に位置している");
                                break;
                                case 1:System.out.println("ヒント:その名の付く魔法を全て会得することで概念魔法に至る");
                                break;
                                case 2:System.out.println("ヒント:ドイツ語でZeitalter der Götterを意味する");
                                break;
                                case 3:System.out.println("ヒント:日本神話における時代区分");
                                break;
                                case 4:System.out.println("ヒント:○○凛子博士");
                                break;
                                case 5:System.out.println("ヒント:○○兄妹");
                                break;
                                case 6:System.out.println("ヒント:図説○○文字入門");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("図説○○文字入門")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
                default:{
                    System.out.println("問題");
                    System.out.println("回答を入力して下さい");
                    for(int i=0;i<7;i++){
                        String Changefullthrottle=scanaria(l);
                        if(Changefullthrottle.equals("用語")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        } else{
                            switch (i) {
                                case 0:System.out.println("不正解! ヒント:「所属に所属しており、位置に位置している」");
                                break;
                                case 1:System.out.println("ヒント:");
                                break;
                                case 2:System.out.println("ヒント:");
                                break;
                                case 3:System.out.println("ヒント:");
                                break;
                                case 4:System.out.println("ヒント:");
                                break;
                                case 5:System.out.println("ヒント:");
                                break;
                                case 6:System.out.println("ヒント:");
                                break;
                            }
                        }
                    }
                    for(int a=0;a<hint.length;a++){
                        String m=hint[a];
                        String Changefullthrottle="0";
                        if(m.equals("")){
                            System.out.println("正解:"+conversion(Changefullthrottle));
                            break;
                        }
                    }
                }
                break;
            }
        }
    }
}