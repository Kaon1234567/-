public class App{
    public static void main(String[] args) {
      System.out.print("【数当てゲーム】");
      int ans =new java.util.Random().nextInt(10);
      for(int i=0;i<5; i++){
        System.out.println("0~9の数字を入力して下さい");
        java.util.Scanner scanner=new java.util.Scanner(System.in);
        int x=scanner.nextInt();
        if(ans == x) {
          System.out.println("アタリ!");
          break;
        } 
        else {
          System.out.println("違います");
          if(ans>=5){
            System.out.println("ヒント:5以上");
            if(ans%2==0){
            System.out.println("ヒント:偶数");
          } else if(ans%2==1){
            System.out.println("ヒント:奇数");
          } 
          else if(ans<5){
            System.out.println("ヒント:5未満");
            if(ans%2==0){
            System.out.println("ヒント:偶数");
          } else if(ans%2==1){
            System.out.println("ヒント:奇数");
          } 
          }
        }
        }
  }
  System.out.println("ゲームを終了します");
}
}